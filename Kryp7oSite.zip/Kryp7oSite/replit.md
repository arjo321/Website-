# KRYP7O Discord Bot Landing Page

## Overview

A modern, responsive landing page for KRYP7O - a Discord bot offering AI-powered moderation, music streaming, and server utilities. Built as a full-stack web application with React frontend and Express backend, featuring a dark theme with purple/blue neon aesthetics and smooth animations. The project follows a monorepo structure with shared TypeScript types and database schema.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Animations**: Framer Motion for smooth transitions and scroll-triggered animations
- **Design System**: Dark theme with purple (#8B5CF6) and blue (#3B82F6) gradient accents, using CSS custom properties for theming

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: TSX for TypeScript execution in development
- **Build System**: esbuild for production bundling
- **Storage Interface**: Abstract storage layer with in-memory implementation (MemStorage) for development, designed for easy database integration
- **Configuration**: JSON-based configuration system (`config.json`) served via REST API for dynamic content management

### Data Layer
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL with Neon Database serverless driver
- **Schema**: Shared TypeScript schema definitions with Zod validation
- **Migrations**: Drizzle Kit for database migrations and schema management
- **Validation**: Zod schemas for runtime type checking and API validation
- **Configuration Management**: TypeScript interfaces for type-safe configuration loading with fallback defaults

### Development Architecture
- **Monorepo Structure**: Organized with `client/`, `server/`, and `shared/` directories
- **Path Aliases**: TypeScript path mapping for clean imports (`@/`, `@shared/`)
- **Hot Reload**: Vite HMR for frontend, tsx watch mode for backend
- **Type Safety**: Full TypeScript coverage across frontend, backend, and shared code
- **Content Management**: Centralized configuration system allowing easy updates to bot data, features, and statistics

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Neon Database PostgreSQL driver for serverless environments
- **drizzle-orm**: Modern TypeScript ORM with excellent type safety
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation
- **@tanstack/react-query**: Powerful data synchronization for React applications
- **framer-motion**: Production-ready motion library for React animations

### UI and Styling
- **@radix-ui/***: Comprehensive collection of low-level UI primitives (40+ components)
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Utility for creating component variants with TypeScript
- **clsx**: Utility for conditional CSS class names

### Development Tools
- **vite**: Fast build tool with hot module replacement
- **tsx**: TypeScript execution engine for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development enhancements

### Form and Validation
- **react-hook-form**: Performant forms with easy validation
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: TypeScript-first schema validation library

### Additional Utilities
- **wouter**: Minimalist routing for React applications
- **date-fns**: Modern JavaScript date utility library
- **cmdk**: Command palette component for React
- **embla-carousel-react**: Embeddable carousel component
- **lucide-react**: Beautiful and consistent icon library