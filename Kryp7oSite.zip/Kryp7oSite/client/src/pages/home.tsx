import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import FeaturesSection from "@/components/features-section";
import HowItWorksSection from "@/components/how-it-works-section";
import ShowcaseSection from "@/components/showcase-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="bg-slate-900 text-white overflow-x-hidden scroll-smooth">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <ShowcaseSection />
      <Footer />
    </div>
  );
}
