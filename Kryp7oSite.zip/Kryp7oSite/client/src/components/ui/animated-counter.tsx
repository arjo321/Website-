import { useState, useEffect } from "react";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";

interface AnimatedCounterProps {
  value: string;
  duration?: number;
  className?: string;
}

export default function AnimatedCounter({ value, duration = 2000, className = "" }: AnimatedCounterProps) {
  const [displayValue, setDisplayValue] = useState("0");
  const motionValue = useMotionValue(0);
  
  // Parse the value to get the numeric part and suffix
  const parseValue = (val: string) => {
    const match = val.match(/^([\d,\.]+)(.*)$/);
    if (!match) return { numeric: 0, suffix: "" };
    
    const numericStr = match[1].replace(/,/g, "");
    let numeric = parseFloat(numericStr);
    const suffix = match[2];
    
    // Convert shorthand notation to actual numbers
    if (suffix.toLowerCase().includes('k')) {
      numeric *= 1000;
    } else if (suffix.toLowerCase().includes('m')) {
      numeric *= 1000000;
    }
    
    return { numeric, suffix };
  };

  const formatNumber = (num: number, suffix: string) => {
    if (suffix.toLowerCase().includes('k')) {
      return `${(num / 1000).toFixed(1)}K${suffix.replace(/k/gi, '').replace(/K/g, '')}`;
    } else if (suffix.toLowerCase().includes('m')) {
      return `${(num / 1000000).toFixed(1)}M${suffix.replace(/m/gi, '').replace(/M/g, '')}`;
    } else if (suffix.includes('%')) {
      return `${num.toFixed(1)}%`;
    } else {
      return `${Math.floor(num).toLocaleString()}${suffix}`;
    }
  };

  useEffect(() => {
    const { numeric: targetValue, suffix } = parseValue(value);
    
    const controls = animate(motionValue, targetValue, {
      duration: duration / 1000,
      ease: "easeOut",
      onUpdate: (latest) => {
        setDisplayValue(formatNumber(latest, suffix));
      }
    });

    return controls.stop;
  }, [value, duration, motionValue]);

  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className={className}
    >
      {displayValue}
    </motion.span>
  );
}