import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface ActivityItem {
  id: string;
  text: string;
  type: 'server' | 'user' | 'feature';
  timestamp: Date;
}

export default function ActivityTicker() {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [currentActivity, setCurrentActivity] = useState<ActivityItem | null>(null);

  const activityTemplates = [
    { text: `${Math.floor(Math.random() * 50) + 10} servers joined today`, type: 'server' as const },
    { text: "AI blocked harmful content", type: 'feature' as const },
    { text: `Music playing in ${Math.floor(Math.random() * 1000) + 500} channels`, type: 'feature' as const },
    { text: `${Math.floor(Math.random() * 100) + 20} new members welcomed`, type: 'user' as const },
    { text: `Analytics updated for ${Math.floor(Math.random() * 200) + 100} servers`, type: 'feature' as const },
    { text: `Ticket #${Math.floor(Math.random() * 9999) + 1000} resolved`, type: 'feature' as const },
    { text: `${Math.floor(Math.random() * 20) + 5} premium servers upgraded`, type: 'server' as const },
    { text: `Auto-moderation active in ${Math.floor(Math.random() * 300) + 200} servers`, type: 'feature' as const },
    { text: `${Math.floor(Math.random() * 1000) + 500} songs added to queues`, type: 'feature' as const },
    { text: `Custom commands running: ${Math.floor(Math.random() * 50) + 100}`, type: 'feature' as const }
  ];

  const getRandomActivity = (): ActivityItem => {
    const templateIndex = Math.floor(Math.random() * activityTemplates.length);
    const template = activityTemplates[templateIndex];
    
    // Generate dynamic text for templates with random numbers
    let dynamicText = template.text;
    
    // Replace any template patterns with new random values
    if (dynamicText.includes('Math.floor')) {
      // Re-evaluate the template string to get fresh random numbers
      if (templateIndex === 0) dynamicText = `${Math.floor(Math.random() * 50) + 10} servers joined today`;
      else if (templateIndex === 2) dynamicText = `Music playing in ${Math.floor(Math.random() * 1000) + 500} channels`;
      else if (templateIndex === 3) dynamicText = `${Math.floor(Math.random() * 100) + 20} new members welcomed`;
      else if (templateIndex === 4) dynamicText = `Analytics updated for ${Math.floor(Math.random() * 200) + 100} servers`;
      else if (templateIndex === 5) dynamicText = `Ticket #${Math.floor(Math.random() * 9999) + 1000} resolved`;
      else if (templateIndex === 6) dynamicText = `${Math.floor(Math.random() * 20) + 5} premium servers upgraded`;
      else if (templateIndex === 7) dynamicText = `Auto-moderation active in ${Math.floor(Math.random() * 300) + 200} servers`;
      else if (templateIndex === 8) dynamicText = `${Math.floor(Math.random() * 1000) + 500} songs added to queues`;
      else if (templateIndex === 9) dynamicText = `Custom commands running: ${Math.floor(Math.random() * 50) + 100}`;
    }
    
    return {
      id: Date.now().toString() + Math.random().toString(),
      text: dynamicText,
      type: template.type,
      timestamp: new Date()
    };
  };

  useEffect(() => {
    // Add initial activity after a short delay
    const initialDelay = setTimeout(() => {
      const activity = getRandomActivity();
      setActivities([activity]);
      setCurrentActivity(activity);
    }, 3000);

    // Then add new activities periodically
    const interval = setInterval(() => {
      const activity = getRandomActivity();
      setActivities(prev => [activity, ...prev.slice(0, 4)]); // Keep last 5 activities
      setCurrentActivity(activity);
    }, 8000 + Math.random() * 7000); // Random intervals between 8-15 seconds

    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, []);

  const getActivityIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'server':
        return '🖥️';
      case 'user':
        return '👤';
      case 'feature':
        return '⚡';
      default:
        return '📡';
    }
  };

  const getActivityColor = (type: ActivityItem['type']) => {
    switch (type) {
      case 'server':
        return 'text-green-400';
      case 'user':
        return 'text-blue-400';
      case 'feature':
        return 'text-purple-400';
      default:
        return 'text-gray-400';
    }
  };

  if (!currentActivity) {
    return null;
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-sm">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentActivity.id}
          initial={{ opacity: 0, x: 300, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 300, scale: 0.8 }}
          transition={{ 
            type: "spring",
            stiffness: 300,
            damping: 30
          }}
          className="bg-slate-800/90 backdrop-blur-sm border border-slate-700 rounded-lg p-3 shadow-lg"
        >
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-sm">
                {getActivityIcon(currentActivity.type)}
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <p className={`text-sm font-medium ${getActivityColor(currentActivity.type)}`}>
                {currentActivity.text}
              </p>
              <p className="text-xs text-gray-500">
                {currentActivity.timestamp.toLocaleTimeString([], { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </p>
            </div>
            <motion.div
              className="w-2 h-2 bg-green-500 rounded-full"
              animate={{ 
                opacity: [1, 0.3, 1],
                scale: [1, 1.2, 1]
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                ease: "easeInOut"
              }}
            />
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}