import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import AnimatedCounter from "./animated-counter";

interface LiveStatsProps {
  initialStats: {
    servers: string;
    users: string;
    uptime: string;
    commands?: string;
  };
}

export default function LiveStats({ initialStats }: LiveStatsProps) {
  const [stats, setStats] = useState(initialStats);
  const [isLive, setIsLive] = useState(false);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prevStats => {
        // Parse current values
        const parseNum = (val: string) => {
          const match = val.match(/^([\d,\.]+)/);
          return match ? parseFloat(match[1].replace(/,/g, '')) : 0;
        };

        const serverCount = parseNum(prevStats.servers);
        const userCount = parseNum(prevStats.users);
        
        // Small random increments to simulate growth
        const serverIncrement = Math.random() < 0.3 ? Math.floor(Math.random() * 3) + 1 : 0;
        const userIncrement = Math.random() < 0.2 ? Math.floor(Math.random() * 50) + 10 : 0;
        
        // Update uptime with small fluctuations (99.8% - 99.9%)
        const uptimeVariation = 99.8 + Math.random() * 0.1;

        return {
          servers: `${(serverCount + serverIncrement).toLocaleString()}`,
          users: `${((userCount + userIncrement) / 1000000).toFixed(1)}M`,
          uptime: `${uptimeVariation.toFixed(1)}%`,
          commands: prevStats.commands || "150+"
        };
      });
      setIsLive(true);
    }, 5000 + Math.random() * 10000); // Random intervals between 5-15 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-2xl mx-auto">
      <motion.div
        className="text-center relative"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <motion.div 
          className="text-3xl font-bold gradient-text relative"
          animate={isLive ? { 
            textShadow: [
              "0 0 10px rgba(139, 92, 246, 0.3)",
              "0 0 20px rgba(139, 92, 246, 0.6)",
              "0 0 10px rgba(139, 92, 246, 0.3)"
            ]
          } : {}}
          transition={{
            repeat: isLive ? Infinity : 0,
            duration: 3,
            ease: "easeInOut"
          }}
        >
          <AnimatedCounter value={stats.servers} />
          {isLive && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-6 w-3 h-3 bg-green-500 rounded-full"
            >
              <motion.div
                className="w-3 h-3 bg-green-500 rounded-full"
                animate={{ 
                  opacity: [1, 0.3, 1],
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 2,
                  ease: "easeInOut"
                }}
              />
            </motion.div>
          )}
        </motion.div>
        <div className="text-gray-400 text-sm">Active Servers</div>
      </motion.div>
      
      <motion.div
        className="text-center relative"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        <motion.div 
          className="text-3xl font-bold gradient-text relative"
          animate={isLive ? { 
            textShadow: [
              "0 0 10px rgba(59, 130, 246, 0.3)",
              "0 0 20px rgba(59, 130, 246, 0.6)", 
              "0 0 10px rgba(59, 130, 246, 0.3)"
            ]
          } : {}}
          transition={{
            repeat: isLive ? Infinity : 0,
            duration: 3.5,
            ease: "easeInOut",
            delay: 0.5
          }}
        >
          <AnimatedCounter value={stats.users} />
          {isLive && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-6 w-3 h-3 bg-blue-500 rounded-full"
            >
              <motion.div
                className="w-3 h-3 bg-blue-500 rounded-full"
                animate={{ 
                  opacity: [1, 0.3, 1],
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  repeat: Infinity, 
                  duration: 2.5,
                  ease: "easeInOut",
                  delay: 0.5
                }}
              />
            </motion.div>
          )}
        </motion.div>
        <div className="text-gray-400 text-sm">Users</div>
      </motion.div>
      
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
      >
        <div className="text-3xl font-bold gradient-text">
          <AnimatedCounter value={stats.uptime} />
        </div>
        <div className="text-gray-400 text-sm">Uptime</div>
      </motion.div>
    </div>
  );
}