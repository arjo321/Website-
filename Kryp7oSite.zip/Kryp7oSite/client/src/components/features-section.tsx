import { motion } from "framer-motion";
import { Shield, Gavel, Music, HandHeart, Ticket, Settings } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { loadConfig, getDefaultConfig } from "@/lib/config";

const iconMap = {
  Shield,
  Gavel,
  Music,
  HandHeart,
  Ticket,
  Settings,
};

export default function FeaturesSection() {
  const { data: config = getDefaultConfig() } = useQuery({
    queryKey: ['/api/config'],
    queryFn: loadConfig,
  });
  return (
    <section id="features" className="py-20 bg-gradient-to-b from-transparent to-slate-800/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold mb-6"
          >
            Powerful <span className="gradient-text">Features</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-400 max-w-2xl mx-auto"
          >
            Everything you need to manage and enhance your Discord server experience
          </motion.p>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {config.features.map((feature, index) => {
            const IconComponent = iconMap[feature.icon as keyof typeof iconMap] || Settings;
            return (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="gradient-border glow-effect"
            >
              <div className="gradient-border-inner p-8 h-full">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center mb-6">
                  <IconComponent className="text-2xl text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}