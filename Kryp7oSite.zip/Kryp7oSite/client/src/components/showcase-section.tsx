import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { loadConfig, getDefaultConfig } from "@/lib/config";

// Discord bot interface mockups - more relevant to bot functionality
const showcaseImages = {
  moderation: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500", // Dashboard/admin interface
  entertainment: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500", // Music/entertainment
  security: "https://images.unsplash.com/photo-1563206767-5b18f218e8de?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500", // Security/lock interface
  support: "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500", // Support/communication
  analytics: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500", // Charts/analytics
  utility: "https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500" // Tools/utilities
};

export default function ShowcaseSection() {
  const { data: config = getDefaultConfig() } = useQuery({
    queryKey: ['/api/config'],
    queryFn: loadConfig,
  });
  return (
    <section id="showcase" className="py-20 bg-gradient-to-b from-transparent to-slate-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold mb-6"
          >
            See KRYP7O in <span className="gradient-text">Action</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-400 max-w-2xl mx-auto"
          >
            Real screenshots from Discord servers using {config.bot.name}
          </motion.p>
        </div>

        {/* Screenshot Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {config.showcase.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="gradient-border glow-effect"
            >
              <div className="gradient-border-inner p-4">
                <div className="relative w-full h-48 bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg overflow-hidden">
                  <img 
                    src={showcaseImages[item.category as keyof typeof showcaseImages] || showcaseImages.utility} 
                    alt={item.title}
                    className="w-full h-full object-cover opacity-40"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="text-xs text-green-400 mb-1">● Live</div>
                    <div className="text-sm font-mono text-gray-300">Discord Bot Interface</div>
                  </div>
                  {/* Overlay to indicate these are placeholder images */}
                  <div className="absolute top-2 right-2 bg-yellow-500/20 backdrop-blur-sm rounded px-2 py-1">
                    <span className="text-xs text-yellow-400">Demo</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-sm">{item.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}