import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Bot } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { loadConfig, getDefaultConfig } from "@/lib/config";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const { data: config = getDefaultConfig() } = useQuery({
    queryKey: ['/api/config'],
    queryFn: loadConfig,
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
        isScrolled ? "nav-blur bg-dark-bg/90" : ""
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
              <Bot className="text-white text-xl" />
            </div>
            <span className="text-2xl font-bold gradient-text">{config.bot.name}</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection("features")}
              className="text-gray-300 hover:text-white transition-colors duration-200"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection("how-it-works")}
              className="text-gray-300 hover:text-white transition-colors duration-200"
            >
              How It Works
            </button>
            <button
              onClick={() => scrollToSection("showcase")}
              className="text-gray-300 hover:text-white transition-colors duration-200"
            >
              Showcase
            </button>
            <Button 
              onClick={() => window.open(config.bot.inviteUrl, '_blank')}
              className="bg-gradient-to-r from-purple-500 to-blue-500 px-6 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity duration-200 glow-effect"
            >
              Add to Discord
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-300 hover:text-white"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden nav-blur bg-slate-900/90 border-t border-gray-800"
          >
            <div className="px-4 py-4 space-y-4">
              <button
                onClick={() => scrollToSection("features")}
                className="block text-gray-300 hover:text-white transition-colors duration-200"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection("how-it-works")}
                className="block text-gray-300 hover:text-white transition-colors duration-200"
              >
                How It Works
              </button>
              <button
                onClick={() => scrollToSection("showcase")}
                className="block text-gray-300 hover:text-white transition-colors duration-200"
              >
                Showcase
              </button>
              <Button 
                onClick={() => {
                  window.open(config.bot.inviteUrl, '_blank');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 px-6 py-2 rounded-lg font-medium"
              >
                Add to Discord
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </nav>
  );
}