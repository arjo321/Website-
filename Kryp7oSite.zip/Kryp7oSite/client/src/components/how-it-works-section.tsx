import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { loadConfig, getDefaultConfig } from "@/lib/config";

export default function HowItWorksSection() {
  const { data: config = getDefaultConfig() } = useQuery({
    queryKey: ['/api/config'],
    queryFn: loadConfig,
  });
  
  const steps = [
    {
      number: "1",
      title: `Invite ${config.bot.name}`,
      description: "Click the \"Add to Discord\" button and select your server. Grant the necessary permissions for optimal functionality."
    },
    {
      number: "2",
      title: "Configure Settings",
      description: "Use simple slash commands to customize moderation rules, welcome messages, and other features to match your server's needs."
    },
    {
      number: "3",
      title: "Enjoy & Relax",
      description: `Let ${config.bot.name} handle the heavy lifting while you focus on building your community. Monitor everything through our intuitive dashboard.`
    }
  ];
  return (
    <section id="how-it-works" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold mb-6"
          >
            How It <span className="gradient-text">Works</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-400 max-w-2xl mx-auto"
          >
            Get started with {config.bot.name} in just a few simple steps
          </motion.p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center relative"
            >
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6 glow-effect">
                <span className="text-2xl font-bold">{step.number}</span>
              </div>
              <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
              <p className="text-gray-400">{step.description}</p>

              {/* Connecting Line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-10 left-1/2 w-full h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 transform translate-x-1/2"></div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}