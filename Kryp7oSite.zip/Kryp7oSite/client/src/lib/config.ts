// Configuration loader for KRYP7O bot data
export interface BotConfig {
  bot: {
    name: string;
    tagline: string;
    description: string;
    clientId: string;
    permissions: string;
    inviteUrl: string;
    supportServer: string;
    version: string;
  };
  stats: {
    servers: string;
    users: string;
    uptime: string;
    commands: string;
  };
  features: Array<{
    icon: string;
    title: string;
    description: string;
  }>;
  showcase: Array<{
    title: string;
    description: string;
    category: string;
  }>;
  pricing: {
    free: {
      name: string;
      price: string;
      features: string[];
    };
    premium: {
      name: string;
      price: string;
      features: string[];
    };
  };
  social: {
    discord: string;
    twitter: string;
    github: string;
  };
  team: Array<{
    name: string;
    role: string;
    avatar: string;
  }>;
}

// Load configuration from the server
export const loadConfig = async (): Promise<BotConfig> => {
  try {
    const response = await fetch('/api/config');
    if (!response.ok) {
      throw new Error('Failed to load configuration');
    }
    return await response.json();
  } catch (error) {
    console.error('Error loading config:', error);
    // Return default config as fallback
    return getDefaultConfig();
  }
};

// Default configuration fallback
export const getDefaultConfig = (): BotConfig => ({
  bot: {
    name: "KRYP7O",
    tagline: "Your Ultimate Discord Assistant",
    description: "Advanced AI moderation, high-quality music streaming, and smart utilities.",
    clientId: "1234567890123456789",
    permissions: "8",
    inviteUrl: "https://discord.com/oauth2/authorize?client_id=1234567890123456789&permissions=8&scope=bot%20applications.commands",
    supportServer: "https://discord.gg/kryp7o-support",
    version: "2.1.0"
  },
  stats: {
    servers: "75,432",
    users: "2.8M",
    uptime: "99.9%",
    commands: "150+"
  },
  features: [
    {
      icon: "Shield",
      title: "AI Auto Moderation",
      description: "Advanced machine learning algorithms detect and prevent spam, toxicity, raids, and malicious content automatically."
    },
    {
      icon: "Gavel", 
      title: "Advanced Moderation Tools",
      description: "Comprehensive moderation suite with custom automod rules, warning systems, detailed audit logs, and staff management."
    },
    {
      icon: "Music",
      title: "Premium Music Player", 
      description: "High-fidelity music streaming from Spotify, YouTube, SoundCloud with playlist management, DJ mode, and audio filters."
    },
    {
      icon: "HandHeart",
      title: "Smart Welcome System",
      description: "Customizable welcome messages, auto-role assignment, verification gates, and member screening with captcha protection."
    },
    {
      icon: "Ticket",
      title: "Professional Tickets",
      description: "Advanced support ticket system with categories, staff assignments, ticket transcripts, and priority handling."
    },
    {
      icon: "Settings", 
      title: "Server Utilities",
      description: "Real-time server analytics, user management, automated announcements, polls, reminders, and custom commands."
    }
  ],
  showcase: [
    {
      title: "AI Moderation Dashboard",
      description: "Real-time threat detection with machine learning analysis",
      category: "moderation"
    },
    {
      title: "Music Player Interface", 
      description: "High-quality streaming with advanced queue management",
      category: "entertainment"
    },
    {
      title: "Welcome & Verification",
      description: "Automated member onboarding with security screening", 
      category: "security"
    },
    {
      title: "Ticket Management",
      description: "Professional support system with staff workflows",
      category: "support"
    },
    {
      title: "Server Analytics",
      description: "Comprehensive insights and member activity tracking",
      category: "analytics"
    },
    {
      title: "Custom Commands",
      description: "Powerful slash command system with permissions",
      category: "utility"
    }
  ],
  pricing: {
    free: {
      name: "Community",
      price: "Free", 
      features: [
        "Basic moderation",
        "Music playback (2 hours/day)",
        "Welcome messages",
        "Community support"
      ]
    },
    premium: {
      name: "Premium",
      price: "$4.99/month",
      features: [
        "AI auto-moderation", 
        "Unlimited music streaming",
        "Advanced tickets",
        "Custom branding",
        "Priority support"
      ]
    }
  },
  social: {
    discord: "https://discord.gg/kryp7o",
    twitter: "https://twitter.com/kryp7obot", 
    github: "https://github.com/kryp7o/discord-bot"
  },
  team: [
    {
      name: "Alex Chen",
      role: "Lead Developer",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Sarah Kim", 
      role: "AI Engineer",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b332e234?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Mike Rodriguez",
      role: "Community Manager", 
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    }
  ]
});