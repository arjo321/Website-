import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api
  
  // Serve bot configuration
  app.get("/api/config", async (req, res) => {
    try {
      const fs = await import("fs/promises");
      const path = await import("path");
      const configPath = path.join(process.cwd(), "config.json");
      const configData = await fs.readFile(configPath, "utf-8");
      const config = JSON.parse(configData);
      res.json(config);
    } catch (error) {
      console.error("Error loading config:", error);
      res.status(500).json({ error: "Failed to load configuration" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  const httpServer = createServer(app);

  return httpServer;
}
