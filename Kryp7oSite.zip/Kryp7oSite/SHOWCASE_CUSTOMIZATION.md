# How to Customize the Showcase Section

The showcase section displays features of your Discord bot with images. Here are the different ways to change these images:

## Method 1: Update Images in `config.json`
Edit the `config.json` file to add custom image URLs:

```json
{
  "showcase": [
    {
      "title": "AI Moderation Dashboard",
      "description": "Real-time threat detection with machine learning analysis",
      "category": "moderation",
      "image": "https://your-custom-image-url.com/moderation.png"
    }
  ]
}
```

## Method 2: Update Image URLs in Component
Edit `client/src/components/showcase-section.tsx` and change the `showcaseImages` object:

```javascript
const showcaseImages = {
  moderation: "https://your-image-url.com/moderation.png",
  entertainment: "https://your-image-url.com/music.png",
  security: "https://your-image-url.com/security.png",
  support: "https://your-image-url.com/tickets.png",
  analytics: "https://your-image-url.com/analytics.png",
  utility: "https://your-image-url.com/commands.png"
};
```

## Method 3: Add Local Images
1. Place your images in `client/public/images/`
2. Update the URLs to use local paths:
   ```javascript
   moderation: "/images/moderation-screenshot.png"
   ```

## Method 4: Use Real Discord Bot Screenshots
The ideal approach is to take actual screenshots of your Discord bot:

1. **Moderation Dashboard**: Screenshot of your bot's moderation interface
2. **Music Player**: Screenshot of your music commands in Discord
3. **Welcome System**: Screenshot of welcome messages and verification
4. **Ticket System**: Screenshot of your ticket interface
5. **Analytics**: Screenshot of server stats or charts
6. **Commands**: Screenshot of your slash commands in action

## Current Setup
- Images have a dark overlay and "Demo" badge
- Shows a "● Live" indicator for authenticity
- Uses a responsive grid layout
- Images are 800x500px for best quality

## Tips
- Use high-quality screenshots (at least 800x500px)
- Ensure images show actual Discord interfaces
- Consider using Discord's dark theme for consistency
- Images should demonstrate the actual features of your bot